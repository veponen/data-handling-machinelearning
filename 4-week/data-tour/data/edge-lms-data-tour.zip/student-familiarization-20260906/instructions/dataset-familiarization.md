# Dataset familiarization

## Purpose

Learn how the artificial Edge-LMS dataset is organized before choosing
features, transformations, models, or evaluation methods.

Estimated time: 45–60 minutes.

## Rules

- Use only the supplied artificial data.
- Do not add your own or another person's real data.
- Do not modify files under `data/student-analysis/`.
- Do not train a model during this activity.
- Record uncertainty instead of silently guessing what a field means.

## A. Orient yourself

Read these files inside `data/student-analysis/`:

1. `README.md`;
2. `dataset-summary.json`;
3. `data_dictionary.md`;
4. `project-requirements-map.md`;
5. `timestamp-taxonomy.yaml`.

Record the dataset ID, build ID, timezone, number of course weeks, number of
students, and number of normalized tables.

## B. Inventory the tables

Run the starter notebook and construct a table inventory containing:

- table name;
- number of rows;
- column names;
- your proposed row grain;
- likely primary key or composite key;
- important time field;
- whether one learner can occur more than once.

Check your interpretation against the corresponding file under `schemas/` and
the relevant entry in `project-requirements-map.md`.

Focus first on `students`, `calendar_days`, `activity_daily`, and
`task_attempts`. Then choose two additional tables relevant to your project.

## C. Understand Monday-only observation and missingness

Using `calendar_days` and `activity_daily`:

1. Count calendar rows by weekday and `lms_available`.
2. Compare Monday rows with Tuesday–Sunday rows.
3. Inspect `observation_status` and `study_observation_status`.
4. Explain why an unavailable day with zero recorded events must not be called
   an inactive study day.
5. Find three nullable fields in the release. For each, describe at least two
   possible meanings and state whether imputation is currently justified.

Your answer must distinguish structural non-observation, an absent event, and
a recorded numerical zero.

## D. Follow one artificial learner

Choose one `student_key` without selecting it because of an interesting final
outcome. Construct a compact eight-week view using documented keys and time
fields. Include at least:

- available-day activity;
- task or quiz attempts;
- module progress.

Create one small table or plot. Describe what the LMS evidence shows and what
it cannot show. Do not assign a personality, motivation, intelligence, mental
state, integrity, or risk label to the learner.

## E. Connect the data to a project card

Locate your project in `project-requirements-map.md` and record:

- support status;
- intended observation grain;
- required tables and field families;
- cutoff or temporal boundary;
- split unit;
- one leakage risk;
- one stated limitation.

If your project is 12 or 13, stop and discuss the documented release limitation
with the instructor. Projects 5, 6, and 8 can be explored, but their delayed
evaluation material is not included in this package.

## Submission

Submit one notebook or short report containing:

- the table inventory;
- the Monday/missingness explanation;
- the one-learner timeline or plot;
- the project-boundary notes;
- three questions you still have about the data.

This is a familiarization exercise. It is acceptable—and expected—to identify
questions that require later investigation.
