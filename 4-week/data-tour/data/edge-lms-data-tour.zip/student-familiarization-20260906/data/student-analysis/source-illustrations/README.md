# Non-row-linked source illustrations

These artificial shape examples use reserved `ILLUSTRATION-*` values. They are not observations and cannot be joined to the released tables.
