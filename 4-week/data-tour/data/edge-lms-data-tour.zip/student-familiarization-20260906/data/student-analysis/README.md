# Synthetic Edge-LMS student ANALYSIS release

Every identity, event, submission, assessment item, score, and reflection in this package is artificial. Never add your own or a classmate's real data.

Dataset: `SYN-DPML-2030`  
Build: `BUILD-17829D481418F54C`  
Profile: `teaching/moderate`

Use the source-derived normalized tables for analysis and machine-learning exercises.

All released data are fully artificial. The fixed eight-week course uses the Europe/Helsinki timezone. Edge-LMS was available to ordinary student activity only on Mondays. Tuesday-Sunday rows describe structural LMS unavailability and unobserved study, not observed inactivity. Identify the observation and missingness mechanism before considering imputation, state assumptions, and compare any imputation with a no-imputation or Monday-aware treatment.

Interpret each release using its row grain, artificial identifiers, time fields, repeated learners and groups, and documented split cautions. The source-like and normalized releases are deliberately separate and contain no row-level linkage. Expected source heterogeneity and broad teaching-quality categories are material to investigate, not affected-record answers. Analysis contracts are specifications, not completed feature tables. Generated text and assessment content are artificial.

Project 12 lacks detailed navigation telemetry, and Project 13 remains pending its paired release. Instructor-provided packages are sufficient; self-generation is optional.

The ETL and analysis releases are deliberately separate and contain no row-level crosswalk. Source illustrations, when present, are shape-only records and cannot be joined to the data. Analysis contracts define grains, cutoffs, leakage, missingness, and split boundaries; they are not completed feature tables or answers.

Detailed material navigation is unavailable for Project 12. Project 13's paired noisy release and Project 5/6/8 evaluation material remain unavailable. The instructor-provided data are sufficient; self-generation is optional.
