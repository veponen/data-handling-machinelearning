# Source-to-analysis map

This is field- and store-level guidance, not a row-level crosswalk or worked normalization procedure.

- artificial account/group/course configuration -> context tables
- global and course quiz logs -> `activity_daily.jsonl` and logical quiz evidence
- accepted artificial submissions -> `task_attempts.jsonl` and controlled text measures
- Grade V1 and attendance snapshots -> `grades.jsonl`, `attendance_sessions.jsonl`, and cutoff-safe progress
- exam sessions/result logs -> privacy-safe `exam_attempts.jsonl`
- announcements and released feedback state -> opportunity-grained interactions

Raw source identifiers, filenames, hashes, and source-record-to-normalized-key pairs are intentionally absent. Tuesday-Sunday study remains structurally unobserved.
