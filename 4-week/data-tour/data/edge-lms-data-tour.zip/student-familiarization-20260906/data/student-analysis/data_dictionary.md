# Normalized data dictionary

The `data/` directory contains exactly 18 source-derived JSONL tables. Each file has one closed schema under `schemas/`. Package-local keys, row grain, time meaning, missingness, quality state, and controlled lineage are part of the table contract. Repeated learner and group observations require the split unit specified by the relevant analysis-use-case contract.

This dictionary describes fully artificial data. Never add your own or a classmate's real data.

All released data are fully artificial. The fixed eight-week course uses the Europe/Helsinki timezone. Edge-LMS was available to ordinary student activity only on Mondays. Tuesday-Sunday rows describe structural LMS unavailability and unobserved study, not observed inactivity. Identify the observation and missingness mechanism before considering imputation, state assumptions, and compare any imputation with a no-imputation or Monday-aware treatment.

Interpret each release using its row grain, artificial identifiers, time fields, repeated learners and groups, and documented split cautions. The source-like and normalized releases are deliberately separate and contain no row-level linkage. Expected source heterogeneity and broad teaching-quality categories are material to investigate, not affected-record answers. Analysis contracts are specifications, not completed feature tables. Generated text and assessment content are artificial.

Project 12 lacks detailed navigation telemetry, and Project 13 remains pending its paired release. Instructor-provided packages are sufficient; self-generation is optional.

Surface text measures are descriptive and are not intelligence, personality, mental-state, integrity, or risk measurements.
