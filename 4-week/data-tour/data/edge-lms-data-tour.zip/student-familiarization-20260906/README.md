# Edge-LMS synthetic-data familiarization package

This package introduces students to the normalized artificial Edge-LMS data
before they begin a project. Every learner, event, score, submission, and text
is artificial. Never add your own or a classmate's real data.

## Contents

- `data/student-analysis/`: an unchanged, independently validated SYN10
  student-analysis release;
- `instructions/dataset-familiarization.md`: a 45–60 minute low-stakes
  familiarization activity;
- `notebooks/00-dataset-tour.ipynb`: a starter notebook that inventories and
  previews the JSONL tables without providing a completed analysis.

Keep `data/student-analysis/` unchanged. Student notes, notebooks, exports, and
figures belong outside that directory so its manifest remains valid.

## Start

1. Read `data/student-analysis/README.md`.
2. Read `instructions/dataset-familiarization.md`.
3. Open `notebooks/00-dataset-tour.ipynb` in Jupyter or VS Code.
4. Save personal work under a new directory such as `work/`.

The notebook requires Python and pandas. The instructor-provided release is
sufficient; generating another variant is optional.

## Important boundaries

- Ordinary LMS activity is observable only on Mondays.
- Tuesday–Sunday rows are structurally unobserved, not proof of inactivity.
- Repeated rows from one learner or group are not independent observations.
- Project specifications define boundaries, not completed features or answers.
- Project 12 lacks required navigation evidence, Project 13's paired release is
  pending, and Projects 5, 6, and 8 do not yet include delayed evaluation truth.

The outer transfer archive is a convenience for distribution. Its bytes are
not part of the generator's deterministic release guarantee; the unchanged
inner `student-analysis` directory is the validated package.
